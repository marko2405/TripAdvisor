document.addEventListener('DOMContentLoaded', function() {
    let input = document.getElementById('searchInput');
    input.addEventListener('input', filterCities);

    function filterCities() {
        let filter = input.value.toUpperCase();
        let cards = document.querySelectorAll('.card');

        cards.forEach(function(card) {
            let title = card.querySelector('.card-title').textContent.toUpperCase();

            if (title.includes(filter)) {
                card.style.display = '';
            } else {
                card.style.display = 'none';
            }
        });
    }
});

