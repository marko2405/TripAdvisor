
//formValues
const firstName = document.getElementById("name")
const cityVisited= document.getElementById("city")
const rating = document.getElementById("rating")
const comment = document.getElementById("comment")
const submitBtn = document.getElementById("form-btn")

// forum.html reviews
const displayUserName = document.getElementById("userNameDisplay")
const displayCityReviewed = document.getElementById("cityVisitedDisplay")
const displayReviewRating = document.getElementById("rateExperienceDisplay")
const displayReviewComment = document.getElementById("commentDisplay")


submitBtn.addEventListener('click',function(e){
    e.preventDefault()
    //fetched values
    let name = firstName.value 
    let visitedCity = cityVisited.value
    let rate = rating.value
    let review = comment.value

    var reviewElement = document.createElement('div');
    reviewElement.className = 'review';
    reviewElement.innerHTML = `
    <div class="container  mt-4" id="review">
      <h4>User Review:</h4>
      <p><strong>Name:</strong> ${name}</p>
      <p><strong>City Visited:</strong> ${visitedCity}</p>
      <p><strong>Rating:</strong> ${rate}</p>
      <p><strong>Comment:</strong> ${review}</p>
      </div>
    `;

    // Append 
    document.getElementById('reviewsContainer').appendChild(reviewElement);

    // Clear 
    document.getElementById('feedbackForm').reset();
  
})

