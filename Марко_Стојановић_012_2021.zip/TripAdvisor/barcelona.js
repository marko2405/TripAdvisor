let jsonData;

fetch("./cities.json")
  .then(res => res.json())
  .then(function(data) {
    jsonData = data;


    // RESTORANI
document.getElementById("restaurants").addEventListener('click',function(){
showRestaurants()
})
document.getElementById("close").addEventListener('click',function(){
    closeModalR()
})

    function showRestaurants() {
        
        let modal = document.getElementById('modalRestaurants');
        let overlay = document.getElementById('overlay');
        modal.style.display = 'block';
        overlay.style.display = 'block';
        renderRestaurants()
        
        
    }

    function closeModalR() {
        
        let modal = document.getElementById('modalRestaurants');
        let overlay = document.getElementById('overlay');

        
        modal.style.display = 'none';
        overlay.style.display = 'none';
    }
    let isClicked = false;
    function renderRestaurants(){
      
        // let restaurantNames= jsonData.cities[3].Restaurants[1].name
        let restaurantsArr = jsonData.cities[3].Restaurants
        let modalRenderingPlace = document.getElementById("renderRestaurants")
        if (isClicked) {
            modalRenderingPlace.innerHTML = '';
             
        }
    
       
         modalRenderingPlace.innerHTML=`<h1 class="naslov mb-4 ">Restaurants in Barcelona</h1> `
        for(let i=0; i<=restaurantsArr.length ;i++){
            modalRenderingPlace.innerHTML +=`
            
            <h2 class="restaurant-name modal-text "> Restaurant Name: ${jsonData.cities[3].Restaurants[i].name}</h3>
            <h3 class="restaurant-rating modal-text"> Rating by the customers: ${jsonData.cities[3].Restaurants[i].rating}</h2>
            <img src="${jsonData.cities[3].Restaurants[i].image}">
            `
        isClicked=true;
        }
        
        
        
    }

// HOTELI
 document.getElementById("hotels").addEventListener('click',function(){
        showHotels()
        })
        document.getElementById("closeH").addEventListener('click',function(){
            closeModalH()
        })
        
            function showHotels() {
                
                let modal = document.getElementById('modalHotels');
                let overlay = document.getElementById('overlay');
        
                
                modal.style.display = 'block';
                overlay.style.display = 'block';
                renderHotels()
            }
        
            function closeModalH() {
                
                let modal = document.getElementById('modalHotels');
                let overlay = document.getElementById('overlay');
        
                
                modal.style.display = 'none';
                overlay.style.display = 'none';
            }

            function renderHotels(){
      
                // let restaurantNames= jsonData.cities[3].Restaurants[1].name
                let hotelsArr = jsonData.cities[3].Hotels
                let modalRenderingPlace = document.getElementById("renderHotels")
                if (isClicked) {
                    modalRenderingPlace.innerHTML = '';
                     
                }
                modalRenderingPlace.innerHTML=`<h1 class="naslov mb-4 ">Hotels in Barcelona</h1> `

                for(let i=0; i<=hotelsArr.length ;i++){
                    modalRenderingPlace.innerHTML +=`
                    
                    <h2 class="hotel-name modal-text "> Hotel Name: ${jsonData.cities[3].Hotels[i].name}</h3>
                    <h3 class="hotel-rating modal-text"> Rating by the customers: ${jsonData.cities[3].Hotels[i].rating}</h2>
                    <img src="${jsonData.cities[3].Hotels[i].image}">
                    `
                    isClicked=true;
                }
                
                
            }
        
    // NIGHTLIFE
    document.getElementById("nightlife").addEventListener('click',function(){
        showNightlife()
        })
        document.getElementById("closeN").addEventListener('click',function(){
            closeModalN()
        })
        
            function showNightlife() {
                
                let modal = document.getElementById('modalNightlife');
                let overlay = document.getElementById('overlay');
        
                
                modal.style.display = 'block'
                overlay.style.display = 'block'
                renderNightlife()
            }
        
            function closeModalN() {
                
                let modal = document.getElementById('modalNightlife')
                let overlay = document.getElementById('overlay')
                modal.style.display = 'none'
                overlay.style.display = 'none'
            }
            function renderNightlife(){
                let nightlifeArr = jsonData.cities[3].Nightlife
                let modalRenderingPlace = document.getElementById("renderNightlife")
                if (isClicked) {
                    modalRenderingPlace.innerHTML = '';
                     
                }
                modalRenderingPlace.innerHTML=`<h1 class="naslov mb-4 "> Clubs in Barcelona</h1> `

                for(let i=0; i<=nightlifeArr.length ;i++){
                    modalRenderingPlace.innerHTML +=`
                    
                    <h2 class="nightlife-name modal-text "> Club Name: ${jsonData.cities[3].Nightlife[i].name}</h3>
                    <h3 class="nightlife-rating modal-text"> Rating by the customers: ${jsonData.cities[3].Nightlife[i].rating}</h2>
                    <img src="${jsonData.cities[3].Nightlife[i].image}">
                    `
                    isClicked=true;
                }
                
                
            }
//MONUMENTS
document.getElementById("monuments").addEventListener('click',function(){
    showMonuments()
    })
    document.getElementById("closeM").addEventListener('click',function(){
        closeModalM()
    })
    
        function showMonuments() {
            
            let modal = document.getElementById('modalMonuments');
            let overlay = document.getElementById('overlay');
    
            
            modal.style.display = 'block';
            overlay.style.display = 'block';
            renderMonuments()
        }
    
        function closeModalM() {
            
            let modal = document.getElementById('modalMonuments');
            let overlay = document.getElementById('overlay');
    
            
            modal.style.display = 'none';
            overlay.style.display = 'none';
        }
        function renderMonuments(){
            let MonumentsArr = jsonData.cities[3].Monuments
            let modalRenderingPlace = document.getElementById("renderMonuments")
            if (isClicked) {
                modalRenderingPlace.innerHTML = '';
                 
            }
            modalRenderingPlace.innerHTML=`<h1 class="naslov mb-4 "> Monuments in Barcelona</h1> `

            for(let i=0; i<=MonumentsArr.length ;i++){
                modalRenderingPlace.innerHTML +=`
                <h2 class="monuments-name modal-text "> Monument Name: ${jsonData.cities[3].Monuments[i].name}</h3>
                <h3 class="monuments-rating modal-text"> Rating by the customers: ${jsonData.cities[3].Monuments[i].rating}</h2>
                <img src="${jsonData.cities[3].Monuments[i].image}">
                `
                isClicked=true;
            }
            
            
        }



})
